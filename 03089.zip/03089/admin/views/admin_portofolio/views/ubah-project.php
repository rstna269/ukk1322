<?php
if (isset($_POST['simpan'])) {
  $id = $_GET['id'];
  $nama_p = $_POST['nama_p'];
  $ket = $_POST['ket'];
  $foto = $_FILES['foto'];
  $namaFoto = $_FILES['foto']['name'];
  $folder = 'foto/';
  $folder = $folder . basename($namaFoto);

  if(empty($namaFoto)) {
    $q = mysqli_query($koneksi, 
    "update project set nama_p ='$nama_p', ket='$ket'
    where id=$id"
    );
    $message = "<div class='alert alert-success'>Project berhasil diubah!</div>";
  } else {
    if(move_uploaded_file($_FILES['foto']['tmp_name'], $folder)) {
      rename("foto/$namaFoto", "foto/$namaFoto");
      $q = mysqli_query($koneksi, 
      "update project set nama_p='$nama_p', ket='$ket', foto='$namaFoto'
      where id=$id");
      
      $message = "<div class='alert alert-success'>Project berhasil diubah!</div>";
    }
  }
}


$id = $_GET['id'];
$getData = mysqli_query($koneksi, "select * from project where id=$id");
$data = mysqli_fetch_assoc($getData);
?>

<div class="row text-dark">
  <div class="col-md-6">
    <h1>
      Ubah Project <?=@$data['nama_p']?> <hr>
     
    </h1>
    <?=@$message?>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label>NAMA</label>
        <input type="text" name="nama_p" class="form-control" value="<?=@$data['nama_p']?>"  required>
      </div>
      <div class="form-group">
        <label>UPLOAD FOTO</label>
        <img src="../../foto/<?=@$data['foto']?>" width="300px">
        <input type="file" name="foto" class="form-control">
      </div>
      <div class="form-group">
        <label>KETERANGAN</label>
        <textarea name="ket" cols="30" rows="3" class="form-control" required><?=@$data['ket']?></textarea>
      </div>
      <button type="submit" name="simpan" class="btn btn-info">Simpan</button>
     <a href="?menu=project" class="btn btn-primary">kembali</a>
    </form>
  </div>
</div>