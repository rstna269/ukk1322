<div class="row">
  <div class="col-md-12  text-dark">
    <h1>HOME.</h1>
    <hr>
    <h3>Hello guys!!.Welcome back,have a good day..... <?=$_SESSION['nama']?></h3>
  </div>
</div>